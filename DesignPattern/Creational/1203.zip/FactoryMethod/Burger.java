package Creational.FactoryMethod;

public interface Burger {
    void prepare();
}
