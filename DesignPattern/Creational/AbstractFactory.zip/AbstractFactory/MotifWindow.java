public class MotifWindow extends Window{
    public MotifWindow() {
        System.out.println("MotifWindow created");
    }
}
