public class PMScrollBar extends ScrollBar{
    public PMScrollBar() {
        System.out.println("PMScrollBar created");
    }
}
