public class MotifScrollBar extends ScrollBar{
    public MotifScrollBar() {
        System.out.println("MotifScrollBar created");
    }
}
