

public class Window {
    public Window() {
        System.out.println("Window created");
    }
}
