public class PMWindow extends Window{
    public PMWindow() {
        System.out.println("PMWindow created");
    }
}
