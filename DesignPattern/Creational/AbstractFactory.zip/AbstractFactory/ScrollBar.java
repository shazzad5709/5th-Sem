public class ScrollBar {
    public ScrollBar() {
        System.out.println("ScrollBar created");
    }
}
